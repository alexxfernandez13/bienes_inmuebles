# bienes_inmuebles


## Get Started

``set PYTHONPATH="/path/to/bienes_inmuebeles`` (Windows)

``export PYTHONPATH="/path/to/bienes_inmuebeles`` (Linux & MAC)

``python bienes_inmuebeles/main.py``


